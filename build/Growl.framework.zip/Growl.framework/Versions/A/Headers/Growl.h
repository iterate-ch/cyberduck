#include "GrowlDefines.h"
#include "GrowlApplicationBridge-Carbon.h"

#ifdef __OBJC__
#include "GrowlApplicationBridge.h"
#endif
