//
//  UtilitySupport.h
//  Keychain
//
//  Created by Wade Tregaskis on Fri Jan 24 2003.
//
//  Copyright (c) 2003, Wade Tregaskis.  All rights reserved.
//  Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
//    * Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
//    * Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
//    * Neither the name of Wade Tregaskis nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.
//  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

#import <Foundation/Foundation.h>
#import <Security/Security.h>


static inline CSSM_DATA* dataFromNSString(NSString *string) {
    CSSM_DATA *result = NULL;

    if (string) {
        result = (CSSM_DATA*)malloc(sizeof(CSSM_DATA));

        result->Length = [string cStringLength];
        result->Data = (uint8*)malloc(result->Length + 1);
        [string getCString:(char*)(result->Data)];
    }
    
    return result;
}

static inline void copyNSDataToData(NSData *source, CSSM_DATA *destination) {
    destination->Length = [source length];

    if (destination->Data) {
        free(destination->Data);
    }

    destination->Data = (uint8*)malloc(destination->Length);
    [source getBytes:(char*)(destination->Data)];
}

// Be very careful using the following function - lots of stuff goes on inside the Keychain & Security frameworks, and the CDSA itself, even for simple requests.  If you get malloc errors or BAD_ACCESS faults, you might want to check over any code which uses this method

// P.S. Yes I know the function name contradicts itself.  I'm lazy and it's consistent.

static inline void copyNSDataToDataNoCopy(NSData *source, CSSM_DATA *destination) {
    if (destination->Data) {
        free(destination->Data);
    }

    destination->Length = [source length];
    destination->Data = (uint8*)[source bytes];
}

static inline CSSM_DATA* dataFromNSData(NSData *data) {
    CSSM_DATA *result = NULL;

    if (data) {
        result = (CSSM_DATA*)malloc(sizeof(CSSM_DATA));

        result->Length = [data length];
        result->Data = (uint8*)malloc(result->Length);
        [data getBytes:(char*)(result->Data)];
    }
    
    return result;
}

static inline NSString* NSStringFromData(const CSSM_DATA *data) {
    if (data) {
        return [NSString stringWithCString:(const char*)(data->Data) length:data->Length];
    } else {
        return nil;
    }
}

static inline NSString* NSStringFromNSData(NSData *data) {
    if (data) {
        return [[[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding] autorelease];
    } else {
        return nil;
    }
}

static inline NSData* NSDataFromNSString(NSString *string) {
    if (string) {
        return [string dataUsingEncoding:NSUTF8StringEncoding];
    } else {
        return nil;
    }
}

static inline NSData* NSDataFromData(const CSSM_DATA *data) {
    if (data) {
        return [NSData dataWithBytes:data->Data length:data->Length];
    } else {
        return nil;
    }
}

// Be very careful using the following function - lots of stuff goes on inside the Keychain & Security frameworks, and the CDSA itself, even for simple requests.  If you get malloc errors or BAD_ACCESS faults, you might want to check over any code which uses this method

static inline NSData* NSDataFromDataNoCopy(const CSSM_DATA *data, BOOL freeWhenDone) {
    if (data) {
        return [NSData dataWithBytesNoCopy:data->Data length:data->Length freeWhenDone:freeWhenDone];
    } else {
        return nil;
    }
}

static inline BOOL OIDsAreEqual(const CSSM_OID *a, const CSSM_OID *b) {
    if (a->Length != b->Length) {
        return NO;
    } else {
        return (memcmp(a->Data, b->Data, a->Length) == 0);
    }
}

/*! @function NSDataFromHumanNSString
    @abstract Converts a human-readable representation of some raw data (i.e. hex form) to the raw data form.
    @discussion This is the opposite operation to NSData's description method, and is entirely compatible and complimentary.  It ignores all newlines, carriage returns, spaces, tabs, and angle-brackets ('<' and '>').  It is, of course, not case sensitive.
    @param string The string containing the human readable hex form, e.g. "<5d2f 5aa3>" or "0x836D" etc.
    @result nil if the string is not in a valid format, the resulting NSData otherwise. */

NSData* NSDataFromHumanNSString(NSString *string);
