//
//  CSSMUtils.h
//  Keychain
//
//  Created by Wade Tregaskis on Thu Mar 13 2003.
//
//  Copyright (c) 2003, Wade Tregaskis.  All rights reserved.
//  Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
//    * Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
//    * Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
//    * Neither the name of Wade Tregaskis nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.
//  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

#import <Foundation/Foundation.h>
#import <Security/Security.h>


NSString* nameOfCertificateType(CSSM_CERT_TYPE certificateType);
NSString* nameOfCertificateEncoding(CSSM_CERT_ENCODING certificateEncoding);

NSString* nameOfBERCode(CSSM_BER_TAG tag);
NSString* stringRepresentationOfBEREncodedData(const CSSM_DATA *dat, CSSM_BER_TAG tag);
NSString* nameOfOIDType(const CSSM_OID *type);

CSSM_DATE_PTR CSSMDateForCalendarDate(NSCalendarDate *date);
NSCalendarDate* calendarDateForCSSMDate(const CSSM_DATE *date);
void copyNSCalendarDateToDate(NSCalendarDate *fromDate, CSSM_DATE *date);
NSCalendarDate* calendarDateForTime(const CSSM_X509_TIME *time);
void copyNSCalendarDateToTime(NSCalendarDate *date, CSSM_X509_TIME *time, CSSM_BER_TAG format);

NSString* nameOfKeyBlob(CSSM_KEYBLOB_TYPE type);
NSString* nameOfTypedFormat(CSSM_KEYBLOB_FORMAT format, CSSM_KEYBLOB_TYPE type);
NSString* nameOfAlgorithm(CSSM_ALGORITHMS algo);
NSString* nameOfKeyClass(CSSM_KEYCLASS class);
NSString* nameOfWrapMode(CSSM_ENCRYPT_MODE mode);

NSString* namesOfAttributes(CSSM_KEYATTR_FLAGS attr);
NSString* namesOfUsages(CSSM_KEYUSE use);

NSString* subjectPublicKeyAsString(const CSSM_X509_SUBJECT_PUBLIC_KEY_INFO *key);
NSString* signatureAsString(const CSSM_X509_SIGNATURE *sig);

NSString* x509NameAsString(const CSSM_X509_NAME *name);
NSString* nameOfOIDAlgorithm(const CSSM_OID *oid);

NSString* nameOfDataFormat(CSSM_X509EXT_DATA_FORMAT format);

NSString* x509AlgorithmAsString(const CSSM_X509_ALGORITHM_IDENTIFIER *algo);
NSString* nameOfOIDAttribute(const CSSM_OID *oid);

NSString* nameOfOIDExtension(const CSSM_OID *oid);
NSString* extensionAsString(const CSSM_X509_EXTENSION *ext);
NSString* extensionsAsString(const CSSM_X509_EXTENSIONS *ext);

void intToDER(uint32 theInt, CSSM_DATA *data);
uint32 DERToInt(const CSSM_DATA *data);
NSData* NSDataForDERFormattedInteger(uint32 value);
